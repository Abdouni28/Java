import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Array {
	
	private Long[] array;
	private int contador;
	
	public Array(int tamanho) {
		
		array = new Long[tamanho];
		contador = 0;
	}

	public void insere (Long valor) {
		
		array[contador++] = valor;
	}
	
	public Long buscaBinaria(Long valor) {
		
		System.out.println("BUSCA BINÁRIA");
		
		String inicio = new SimpleDateFormat("HH:mm:ss,SSS").format(Calendar.getInstance().getTime());
		
		int limiteMinimo = 0;
		int limiteMaximo = contador - 1;
		int atual;

		do {

			atual = (limiteMinimo + limiteMaximo) / 2;

			if (array[atual].equals(valor)) {

				String fim = new SimpleDateFormat("HH:mm:ss,SSS").format(Calendar.getInstance().getTime());

				System.out.println(inicio + " - " + fim);
				
				return array[atual];
			} else if (limiteMinimo > limiteMaximo) {

				return -999999L;
			}

			if (array[atual] < valor) {

				limiteMinimo = atual + 1;
			} else {

				limiteMaximo = atual - 1;
			}

		} while (array[atual] != valor);

		return null;
	}
	
	public Long buscaLinear(Long valor) {
		
		System.out.println("BUSCA LINEAR");
		
		String inicio = new SimpleDateFormat("HH:mm:ss,SSS").format(Calendar.getInstance().getTime());
		
		for(int i = 0; i <array.length; i++) {
			
			if(array[i].equals(valor)) {
				
				String fim = new SimpleDateFormat("HH:mm:ss,SSS").format(Calendar.getInstance().getTime());

				System.out.println(inicio + " - " + fim);
				
				return array[i];
			}
		}
		
		return -99999L;
	}
}

public class App {

	public static void main(String[] args) {

		Array array = new Array(1000000);
		
		for(int i = 0; i < 1000000; i++) {
			
			array.insere(Long.valueOf(i));
		}
		
		/*BINÁRIA*/
		System.out.println(array.buscaBinaria(999999L));
		
		System.out.println("********************************************");
		
		/*LINEAR*/		
		System.out.println(array.buscaLinear(999999L));
	}

}

package ordenacoes_simples;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Random;

public class Array {
	
	private int[] array;
	private int contador;
	
	private SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss,SSS");
	
	public Array(int tamanho) {
		
		array = new int[tamanho];
		contador = 0;
	}

	public void preenche () {
		
		Random aleatorio = new Random();
		
		for(int i = 0; i < array.length; i++) {
			
			array[contador++] =  aleatorio.nextInt(101);
		}
	}
	
	public void exibe() {
		
		for(int i = 0; i < array.length; i++) {
			
			System.out.print(array[i] + " ");
		}

		System.out.println();
	}
	
	public void ordenacaoBolha() {
		
		System.out.println("ORDENAÇÃO MÉTODO BOLHA");
		
		String inicio = sdf.format(Calendar.getInstance().getTime());
		
		int temporaria;
		
		for(int i = (array.length - 1); i > 1; i--) {
			for(int j = 0; j < i; j++) {
				
				if(array[j] > array[j + 1]) {
					
					temporaria = array[j];
					
					array[j] = array[j + 1];
					array[j + 1] = temporaria;
				}
			}
		}
		
		exibe();
		
		String fim = sdf.format(Calendar.getInstance().getTime());

		System.out.println(inicio + " - " + fim);
	}

	public void ordenacaoSelecao() {
		
		System.out.println("ORDENAÇÃO MÉTODO SELEÇÃO");
		
		String inicio = sdf.format(Calendar.getInstance().getTime());
		
		int temporaria, menorValor;
		
		for(int i = 0; i < (array.length - 1); i++) {
			
			menorValor = i;
			
			for(int j = (i + 1); j < array.length; j++) {
				
				if(array[menorValor] > array[j]) {
					
					menorValor = j;
				}
			}
			
			temporaria = array[i];
			
			array[i] = array[menorValor];
			array[menorValor] = temporaria;
		}
		
		exibe();
		
		String fim = sdf.format(Calendar.getInstance().getTime());

		System.out.println(inicio + " - " + fim);
	}
	
	public void ordenacaoInsercao() {
		
		System.out.println("ORDENAÇÃO MÉTODO INSERÇÃO");
		
		String inicio = sdf.format(Calendar.getInstance().getTime());
		
		int temporaria;
		
		for(int i = 1; i < array.length; i++) {
			
			temporaria = array[i];
			
			int j = i;
			while(j > 0 && array[j - 1] >= temporaria) {
				
				array[j] = array[j - 1];
				j--;
			}
			
			array[j] = temporaria;
		}
		
		exibe();
		
		String fim = sdf.format(Calendar.getInstance().getTime());

		System.out.println(inicio + " - " + fim);
	}
}
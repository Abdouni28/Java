package ordenacoes_simples;

public class App {

	public static void main(String[] args) {

		Array array = new Array(20);
		
		array.preenche();
		
		System.out.println("Antes das ordenações");
		array.exibe();
		
		System.out.println("********************************");
		
		array.ordenacaoBolha();

		System.out.println("********************************");
		
		array.ordenacaoSelecao();
		
		System.out.println("********************************");
		
		array.ordenacaoInsercao();
	}

}
